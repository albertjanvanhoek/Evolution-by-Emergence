# Organizational Accessibility — scientific master v4

Files:
- `main.tex` — Overleaf-ready manuscript
- `references.bib` — bibliography database

Compilation:
- LaTeX compiler: pdfLaTeX, LuaLaTeX, or XeLaTeX
- Bibliography processor: Biber

The manuscript implements the v4 scientific master, including the final distinction between:
- `S \subseteq \Theta \times Z` for the general joint architecture–state accessibility kernel; and
- `U \subseteq \Theta` for architecture-only novel-successor quantities such as `\Lambda_\tau(U)`.
