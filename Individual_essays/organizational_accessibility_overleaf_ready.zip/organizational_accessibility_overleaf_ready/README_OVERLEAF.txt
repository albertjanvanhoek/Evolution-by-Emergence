OVERLEAF SETUP
==============

This package is arranged to match the paths already used in main.tex.

Files:
  main.tex
  references.bib
  figures/accessibility_routes.pdf
  figures/seeding_trajectories.pdf
  figures/bifurcation_diagram.pdf
  make_figures.py

Overleaf:
1. Create a New Project -> Upload Project and upload the ZIP.
2. Make sure main.tex is selected as the Main document (Menu -> Main document).
3. Compile with pdfLaTeX. The manuscript uses biblatex with backend=biber;
   Overleaf normally runs Biber automatically as needed.
4. Do not move the three PDF figures out of the figures/ folder unless you also
   change the paths in the three \includegraphics commands.

The Python script is not required for Overleaf compilation. It is provided only
for regenerating the figure PDFs locally. By default it writes the exact figure
filenames into ./figures/.
