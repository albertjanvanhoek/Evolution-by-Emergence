#!/usr/bin/env python3
"""Generate the three figures for "Organizational Accessibility" (v7).

Writes, by default, into ./figures/ with the exact filenames the manuscript
expects:

    figures/accessibility_routes.pdf     (Figure 1, schematic)
    figures/seeding_trajectories.pdf     (Figure 2, seeding + return-path control)
    figures/bifurcation_diagram.pdf      (Figure 3, bifurcation structure)

Usage:
    python make_figures.py                 # all three, into ./figures
    python make_figures.py --outdir build  # elsewhere
    python make_figures.py --only bifurcation
    python make_figures.py --titles        # keep in-figure titles (off by default;
                                           # the LaTeX captions already carry them)
    python make_figures.py --png           # also emit PNGs for quick viewing

Requires NumPy, SciPy, Matplotlib. Deterministic: no randomness anywhere.
Figure 2 and Figure 3 are recomputed from Eqs. (14)-(17) and (18)-(22) of the
manuscript; the script asserts the published values before writing.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib as mpl
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

mpl.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

# --------------------------------------------------------------------------
# Worked-example parameters (Sections 5-6 of the manuscript)
# --------------------------------------------------------------------------
U = 30.0
V = 2.0
J_HIGH = 1.2
J_LOW = 0.9
T_SEED = 50.0
T_DROP = 150.0
T_PLOT_END = 500.0
T_CHECK_END = 1000.0
SEED = 1e-4
RTOL, ATOL = 1e-10, 1e-12

# --------------------------------------------------------------------------
# Shared style
# --------------------------------------------------------------------------
# Text width of the article class with a4paper + margin=2.6cm is 15.8 cm.
TEXTWIDTH_IN = 15.8 / 2.54

# Colour-blind-safe (Wong / seaborn "colorblind"). Roles are kept consistent
# across figures: blue = a, orange = b, green = c, red = w / inert product.
C_A, C_B, C_C, C_W = "#0173B2", "#DE8F05", "#029E73", "#CC3311"
C_UNSTABLE = "#DE8F05"
C_AB = "#CC3311"
C_AB_UNSTABLE = "#7B5AA6"
C_FREE = "#029E73"
C_RULE = "#4D4D4D"
C_SHADE = "#D9D9D9"


def apply_style() -> None:
    """Match the document's Computer Modern body text and embed TrueType fonts.

    matplotlib ships cmr10, so figure labels sit in the same family as the
    surrounding LaTeX text without needing a usetex round trip. pdf.fonttype 42
    writes TrueType rather than the Type 3 subsets many journals reject.
    """
    mpl.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["cmr10", "Computer Modern Roman", "DejaVu Serif"],
            "mathtext.fontset": "cm",
            "axes.formatter.use_mathtext": True,
            "axes.unicode_minus": False,  # required by cmr10
            "font.size": 9,
            "axes.labelsize": 9,
            "axes.titlesize": 9,
            "legend.fontsize": 8,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "axes.linewidth": 0.7,
            "axes.edgecolor": "#333333",
            "axes.labelcolor": "#1A1A1A",
            "text.color": "#1A1A1A",
            "xtick.color": "#333333",
            "ytick.color": "#333333",
            "xtick.direction": "out",
            "ytick.direction": "out",
            "xtick.major.width": 0.7,
            "ytick.major.width": 0.7,
            "xtick.major.size": 3.0,
            "ytick.major.size": 3.0,
            "lines.linewidth": 1.4,
            "lines.solid_capstyle": "round",
            "legend.frameon": False,
            "legend.handlelength": 1.8,
            "legend.columnspacing": 1.4,
            "figure.dpi": 150,
            "savefig.dpi": 300,
            "savefig.bbox": "standard",  # exact figsize: no rescaling in LaTeX
            "pdf.fonttype": 42,
            "pdf.compression": 6,
        }
    )


def despine(ax, keep=("left", "bottom")) -> None:
    for side, spine in ax.spines.items():
        spine.set_visible(side in keep)


# ==========================================================================
# Model
# ==========================================================================
def rhs(t, state, J, eta):
    """Eqs. (18)-(22). eta = 1 recovers Eqs. (14)-(17) with w identically 0."""
    a, b, c, r, w = state
    return_flux = V * r * c
    return [
        r * b + eta * return_flux - a,
        r * a - b,
        U * r * a * c - c,
        J - r - (r * b + return_flux + r * a + U * r * a * c),
        (1.0 - eta) * return_flux - w,
    ]


def ab_equilibrium(J):
    """Resident A-B state for J > 1: r* = 1, a* = b* = (J - 1)/2."""
    return [0.5 * (J - 1.0), 0.5 * (J - 1.0), 0.0, 1.0, 0.0]


def run_schedule(eta, seeded, t_end=T_PLOT_END, n=4000):
    """Integrate the three phases and return (t, y) sampled on a dense grid.

    Phase 0: t in [0, 50]   at J = 1.2, starting from the A-B equilibrium.
    Seed:    c += 1e-4, r -= 1e-4 (seeded runs only).
    Phase 1: t in [50, 150] at J = 1.2.
    Phase 2: t in [150, t_end] at J = 0.9.
    """
    segments = []
    y0 = ab_equilibrium(J_HIGH)

    for (t0, t1), J in (
        ((0.0, T_SEED), J_HIGH),
        ((T_SEED, T_DROP), J_HIGH),
        ((T_DROP, t_end), J_LOW),
    ):
        if t0 == T_SEED and seeded:
            y0 = list(y0)
            y0[2] += SEED
            y0[3] -= SEED
        span = max(2, int(round(n * (t1 - t0) / t_end)))
        grid = np.linspace(t0, t1, span)
        sol = solve_ivp(
            rhs, (t0, t1), y0, args=(J, eta),
            method="RK45", rtol=RTOL, atol=ATOL, t_eval=grid, dense_output=True,
        )
        if not sol.success:
            raise RuntimeError(sol.message)
        segments.append((sol.t, sol.y))
        y0 = sol.y[:, -1]

    t = np.concatenate([s[0] for s in segments])
    y = np.concatenate([s[1] for s in segments], axis=1)
    return t, y


def validate_dynamics() -> None:
    """Assert the endpoint values quoted in Section 5 before drawing anything."""
    _, y = run_schedule(eta=1.0, seeded=True, t_end=T_CHECK_END, n=8000)
    a, b, c, r, w = y[:, -1]
    published = (0.185854, 0.033333, 0.501460, 0.179352)
    got = (a, b, c, r)
    if max(abs(g - p) for g, p in zip(got, published)) > 5e-6:
        raise AssertionError(f"eta=1 endpoint {got} != published {published}")
    if abs(w) > 1e-9:
        raise AssertionError(f"eta=1 inert product should vanish, got {w}")

    _, y0 = run_schedule(eta=0.0, seeded=True, t_end=T_CHECK_END, n=8000)
    a0, b0, c0, r0, w0 = y0[:, -1]
    if max(abs(v) for v in (a0, b0, c0, w0)) > 1e-6 or abs(r0 - J_LOW) > 1e-6:
        raise AssertionError(f"eta=0 endpoint should collapse to r=0.9, got {y0[:, -1]}")

    if abs(total_active(R_FOLD) - 0.241571) > 1e-5:
        raise AssertionError("fold abundance does not match the expanded branch")
    print("  checks passed: eta=1 endpoint, eta=0 collapse, fold abundance")


# --- equilibrium branches (Section 6) --------------------------------------
def supply(r):
    """Eq. (23): J(r) on the expanded branch."""
    return r + (1.0 / r + 1.0 + (1.0 / r**2 - 1.0) / V) / U


def total_active(r):
    """a + b + c on the expanded branch."""
    return 1.0 / (U * r) + 1.0 / U + (1.0 - r**2) / (U * V * r**2)


R_FOLD = brentq(lambda r: U * r**3 - r - 2.0 / V, 1e-12, 1.0)
J_FOLD = supply(R_FOLD)
J_INV = 1.0 + 2.0 / U


# ==========================================================================
# Figure 1 - accessibility routes (schematic)
# ==========================================================================
def figure_accessibility_routes(show_title: bool):
    fig, ax = plt.subplots(
        figsize=(0.94 * TEXTWIDTH_IN, 0.94 * TEXTWIDTH_IN * 0.50), layout="constrained")
    fig.get_layout_engine().set(w_pad=0.01, h_pad=0.01)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    lineage_face, lineage_edge = "#EAF2F8", "#3B7EA8"
    comp_face, comp_edge = "#FBF0E2", "#C77B26"
    target_face, target_edge = "#EAF4EF", "#1F7A5C"

    def box(x0, y0, x1, y1, lines, face, edge, weight=None, fs=8.0):
        ax.add_patch(
            FancyBboxPatch(
                (x0, y0), x1 - x0, y1 - y0,
                boxstyle="round,pad=0,rounding_size=2.4",
                linewidth=0.9, facecolor=face, edgecolor=edge, zorder=3,
            )
        )
        cx, cy = 0.5 * (x0 + x1), 0.5 * (y0 + y1)
        n = len(lines)
        step = 6.4
        for i, line in enumerate(lines):
            ax.text(
                cx, cy + (n - 1) * step / 2 - i * step, line,
                ha="center", va="center", fontsize=fs, zorder=4,
                fontweight=(weight if i == 0 else None),
                color="#1A1A1A" if i == 0 else "#454545",
            )

    # Grouping frame for the lineage-local routes.
    ax.add_patch(
        FancyBboxPatch(
            (1.5, 30.0), 38.0, 66.0,
            boxstyle="round,pad=0,rounding_size=3",
            linewidth=0.8, linestyle=(0, (4, 3)),
            facecolor="none", edgecolor="#9BB7C8", zorder=1,
        )
    )
    ax.text(3.5, 92.0, "lineage-local routes", fontsize=7.5,
            color="#5D7C8E", ha="left", va="center", style="italic")

    box(5, 74, 36, 88, ["Retained state / basin", "Mechanism I"],
        lineage_face, lineage_edge, weight="bold")
    box(5, 54, 36, 70, ["Inherited architecture", "+ exposure", "Mechanism II"],
        lineage_face, lineage_edge, weight="bold")
    box(5, 34, 36, 48, ["Variation process $Q$", "Mechanism III"],
        lineage_face, lineage_edge, weight="bold")
    box(20, 8, 62, 26,
        ["External module / partner pool $M_t$",
         r"recombination $\cdot$ HGT $\cdot$ symbiosis",
         "cross-scale bridge"],
        comp_face, comp_edge, weight="bold", fs=7.6)
    ax.text(41.0, 3.0, "compositional / distributed route", fontsize=7.5,
            color="#A2762F", ha="center", va="center", style="italic")

    box(68, 45, 99, 67,
        ["Effective organizational", "accessibility",
         r"$\mathcal{A}_\tau,\ \mathcal{H}_\tau$"],
        target_face, target_edge, weight="bold")

    def arrow(xy_from, xy_to, colour, rad=0.0, style="-"):
        ax.add_patch(
            FancyArrowPatch(
                xy_from, xy_to,
                arrowstyle="-|>", mutation_scale=9,
                linewidth=1.0, linestyle=style,
                color=colour, zorder=2,
                connectionstyle=f"arc3,rad={rad}",
                shrinkA=1.5, shrinkB=2.5,
            )
        )

    arrow((36, 81), (68, 62), lineage_edge, rad=-0.10)
    arrow((36, 62), (68, 57), lineage_edge, rad=-0.04)
    arrow((36, 41), (68, 52), lineage_edge, rad=0.10)
    arrow((62, 19), (76, 45), comp_edge, rad=-0.20, style=(0, (5, 2.5)))

    if show_title:
        ax.set_title(
            "Distinct routes by which realized organization\n"
            "can condition later accessibility",
            fontsize=9, pad=6,
        )
    return fig


# ==========================================================================
# Figure 2 - seeding and return-path control
# ==========================================================================
def figure_seeding_trajectories(show_title: bool, shared_y: bool = True):
    runs = [
        ("Seed $C$, productive return ($\\eta = 1$)", dict(eta=1.0, seeded=True)),
        ("No seed", dict(eta=1.0, seeded=False)),
        ("Seed $C$, same return flux diverted to waste ($\\eta = 0$)",
         dict(eta=0.0, seeded=True)),
    ]

    fig, axes = plt.subplots(
        3, 1, figsize=(0.96 * TEXTWIDTH_IN, 0.96 * TEXTWIDTH_IN * 0.74),
        sharex=True, sharey=shared_y, layout="constrained",
    )
    fig.get_layout_engine().set(hspace=0.09, h_pad=0.02, w_pad=0.02)

    handles = None
    for k, (ax, (title, kwargs)) in enumerate(zip(axes, runs)):
        t, y = run_schedule(**kwargs)
        a, b, c, _, w = y

        ax.axvspan(T_DROP, T_PLOT_END, color="#F2F2F2", zorder=0, linewidth=0)
        for x in (T_SEED, T_DROP):
            ax.axvline(x, color=C_RULE, linewidth=0.7, linestyle=(0, (1, 2)), zorder=1)

        # a and b coincide until the seed, so a is drawn heavier underneath.
        ax.plot(t, a, color=C_A, label="$a$", linewidth=2.0, zorder=4)
        ax.plot(t, b, color=C_B, label="$b$", linewidth=1.1, zorder=6)
        ax.plot(t, c, color=C_C, label="$c$", linewidth=1.5, zorder=5)
        ax.plot(t, w, color=C_W, label="$w$ (inert)", linestyle=(0, (4, 2)),
                linewidth=1.2, zorder=3)

        if handles is None:
            handles, labels = ax.get_legend_handles_labels()

        ax.set_xlim(0, T_PLOT_END)
        if shared_y:
            ax.set_ylim(-0.03, 0.86)
            ax.set_yticks([0.0, 0.2, 0.4, 0.6, 0.8])
        else:
            ax.set_ylim(bottom=min(-0.01, 1.05 * min(y.min(), 0)))
        ax.set_ylabel("Abundance")
        despine(ax)
        ax.tick_params(labelbottom=(k == 2))

        ax.set_title(f"({'abc'[k]})  {title}", loc="left", fontsize=8.5, pad=3.5)

    axes[2].set_xlabel("Time $t$")

    # Event labels once, in the empty middle panel, clear of titles and data.
    for x, text in ((T_SEED, "seed $C$"), (T_DROP, r"$J:\ 1.2 \rightarrow 0.9$")):
        axes[1].annotate(
            text, xy=(x, 0.42), xycoords=("data", "axes fraction"),
            xytext=(4, 0), textcoords="offset points", rotation=90,
            ha="left", va="center", fontsize=7.5, color=C_RULE,
        )

    fig.legend(handles, labels, loc="outside lower center", ncol=4)
    fig.align_ylabels(axes)
    if show_title:
        fig.suptitle("Seeding and resource-consuming return-path control", y=0.99)
    return fig


# ==========================================================================
# Figure 3 - bifurcation structure
# ==========================================================================
def figure_bifurcation_diagram(show_title: bool):
    j_min, j_max = 0.5, 1.35
    fig, ax = plt.subplots(
        figsize=(0.92 * TEXTWIDTH_IN, 0.92 * TEXTWIDTH_IN * 0.62), layout="constrained")
    fig.get_layout_engine().set(h_pad=0.02, w_pad=0.02)

    # Expanded branch, parametrised by r and split at the fold.
    r_lo = brentq(lambda r: supply(r) - j_max, 1e-6, R_FOLD)
    r_stable = np.linspace(r_lo, R_FOLD, 900)
    r_unstable = np.linspace(R_FOLD, 1.0 - 1e-9, 900)

    ax.axvspan(J_FOLD, J_INV, color=C_SHADE, alpha=0.5, zorder=0, linewidth=0)

    ax.plot(supply(r_stable), total_active(r_stable), color=C_A, zorder=5)
    ax.plot(supply(r_unstable), total_active(r_unstable), color=C_UNSTABLE,
            linestyle=(0, (5, 2.5)), zorder=5)

    j_free = np.linspace(j_min, 1.0, 200)
    ax.plot(j_free, np.zeros_like(j_free), color=C_FREE, zorder=4)

    j_ab_s = np.linspace(1.0, J_INV, 200)
    j_ab_u = np.linspace(J_INV, j_max, 200)
    ax.plot(j_ab_s, j_ab_s - 1.0, color=C_AB, zorder=5)
    ax.plot(j_ab_u, j_ab_u - 1.0, color=C_AB_UNSTABLE,
            linestyle=(0, (5, 2.5)), zorder=5)

    ax.plot([J_FOLD], [total_active(R_FOLD)], marker="o", markersize=3.6,
            color=C_A, markeredgecolor="white", markeredgewidth=0.6, zorder=6)

    # Threshold rules, labelled on a top axis rather than as free-floating text.
    thresholds = ((J_FOLD, r"$J_{\rm fold}$"), (1.0, r"$R_{\rm org}=1$"),
                  (J_INV, r"$J_{\rm inv}$"))
    for x, _ in thresholds:
        ax.axvline(x, color=C_RULE, linewidth=0.7, linestyle=(0, (1, 2.2)), zorder=1)
    secax = ax.secondary_xaxis("top")
    secax.set_xticks([x for x, _ in thresholds], labels=[t for _, t in thresholds])
    secax.tick_params(labelsize=8, colors=C_RULE, length=2.5, width=0.7, pad=1.5)
    secax.spines["top"].set_visible(False)

    # Span marking the interval where both states are stable: the paper's result.
    y_span = 1.20
    ax.annotate("", xy=(J_FOLD, y_span), xytext=(J_INV, y_span),
                arrowprops=dict(arrowstyle="<->", linewidth=0.7, color="#6E6E6E",
                                shrinkA=0, shrinkB=0), zorder=2)
    ax.text(0.5 * (J_FOLD + J_INV), y_span - 0.035,
            "bistable: expanded state persists where it cannot invade",
            ha="center", va="top", fontsize=7.5, color="#5A5A5A", zorder=2)

    # Direct labels beat a legend box that sits on top of the curves.
    ax.annotate("expanded equilibrium (stable)", xy=(1.185, supply_inverse_total(1.185)),
                xytext=(1.335, 0.66), ha="right", va="center",
                fontsize=8, color=C_A,
                arrowprops=dict(arrowstyle="-", linewidth=0.6, color=C_A,
                                shrinkA=2, shrinkB=3,
                                connectionstyle="arc3,rad=0.15"))
    ax.annotate("expanded equilibrium (unstable)", xy=(0.80, 0.137),
                xytext=(0.80, 0.30), ha="center", va="bottom",
                fontsize=8, color=C_UNSTABLE,
                arrowprops=dict(arrowstyle="-", linewidth=0.6, color=C_UNSTABLE,
                                shrinkA=3, shrinkB=3))
    ax.annotate("organization-free (stable)", xy=(0.515, 0.0),
                xytext=(0, 5), textcoords="offset points",
                ha="left", va="bottom", fontsize=8, color=C_FREE)
    ax.annotate("$A$-$B$ (stable)", xy=(1.037, 0.037),
                xytext=(1.150, 0.043), ha="left", va="center",
                fontsize=8, color=C_AB,
                arrowprops=dict(arrowstyle="-", linewidth=0.6, color=C_AB,
                                shrinkA=2, shrinkB=3))
    ax.annotate("$A$-$B$ (unstable to $C$)", xy=(1.28, 0.28),
                xytext=(0, 9), textcoords="offset points",
                ha="center", va="bottom", fontsize=8, color=C_AB_UNSTABLE)

    ax.set_xlim(j_min, j_max)
    ax.set_ylim(-0.035, 1.26)
    ax.set_xlabel("External supply $J$")
    ax.set_ylabel("Total active abundance $a + b + c$")
    despine(ax)
    if show_title:
        ax.set_title(f"Bifurcation structure for $u = {U:.0f}$, $v = {V:.0f}$", pad=16)
    return fig


def supply_inverse_total(j):
    """Total active abundance on the stable expanded branch at supply j."""
    r = brentq(lambda r: supply(r) - j, 1e-9, R_FOLD)
    return total_active(r)


# ==========================================================================
FIGURES = {
    "routes": ("accessibility_routes", figure_accessibility_routes),
    "seeding": ("seeding_trajectories", figure_seeding_trajectories),
    "bifurcation": ("bifurcation_diagram", figure_bifurcation_diagram),
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", default="figures", type=Path)
    parser.add_argument("--only", choices=sorted(FIGURES), action="append")
    parser.add_argument("--titles", action="store_true",
                        help="draw in-figure titles (the LaTeX captions already carry them)")
    parser.add_argument("--png", action="store_true", help="also write PNGs")
    args = parser.parse_args()

    apply_style()
    args.outdir.mkdir(parents=True, exist_ok=True)

    print(f"r_fold = {R_FOLD:.6f}   J_fold = {J_FOLD:.6f}   J_inv = {J_INV:.6f}")
    validate_dynamics()

    wanted = args.only or list(FIGURES)
    for key in wanted:
        stem, builder = FIGURES[key]
        fig = builder(show_title=args.titles)
        target = args.outdir / f"{stem}.pdf"
        fig.savefig(target)
        if args.png:
            fig.savefig(target.with_suffix(".png"))
        plt.close(fig)
        print(f"  wrote {target}")


if __name__ == "__main__":
    main()
